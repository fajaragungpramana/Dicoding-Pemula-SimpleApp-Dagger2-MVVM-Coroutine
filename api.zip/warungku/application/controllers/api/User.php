<?php

use Restserver\Libraries\REST_Controller;

defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class User extends REST_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('User_model');
    }

    function index_get()
    {
        $id = $this->get('id');

        if ($id !== null) {
            $user_query = $this->User_model->getUser($id);

            if ($user_query) {

                $this->response([
                    'status' => true,
                    'user' => $user_query
                ], REST_Controller::HTTP_OK);
            } else {

                $this->response([
                    'status' => false,
                    'message' => 'No user were found!'
                ], REST_Controller::HTTP_NOT_FOUND);
            }
        } else {

            $this->response([
                'status' => false,
                'message' => 'Provide id!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }
}
