<?php

use Restserver\Libraries\REST_Controller;

defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class Stock extends REST_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('Stock_model');
    }

    function index_get()
    {
        $name = $this->get('name');

        $stock_query = $this->Stock_model->getStock($name);

        if ($stock_query) {

            $this->response([
                'status' => true,
                'stocks' => $stock_query
            ], REST_Controller::HTTP_OK);
        } else {

            $this->response([
                'status' => false,
                'message' => 'No stocks were found!'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }

    function detail_get()
    {
        $id = $this->get('id');

        if ($id !== null) {
            $stock_query = $this->Stock_model->getDetail($id);

            if ($stock_query) {

                $this->response([
                    'status' => true,
                    'stock' => $stock_query
                ], REST_Controller::HTTP_OK);
            } else {

                $this->response([
                    'status' => false,
                    'message' => 'Stock not found!'
                ], REST_Controller::HTTP_NOT_FOUND);
            }
        } else {

            $this->response([
                'status' => false,
                'message' => 'Provide an id!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }
}
