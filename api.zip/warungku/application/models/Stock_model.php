<?php

class Stock_model extends CI_Model
{

    public function getStock($name = null)
    {
        if ($name === null)
            return $this->db->get('stocks')->result_array();
        else {
            $this->db->like('name', $name, 'both');
            return $this->db->get('stocks')->result_array();
        }
    }

    public function getDetail($id = null)
    {
        return $this->db->get_where('stocks', ['id' => $id])->row_object();
    }
}
