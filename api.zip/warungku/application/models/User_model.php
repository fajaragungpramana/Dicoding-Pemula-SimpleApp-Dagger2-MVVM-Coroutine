<?php

class User_model extends CI_Model
{

    public function getUser($id = null)
    {
        return $this->db->get_where('users', ['id' => $id])->row_object();
    }
}
